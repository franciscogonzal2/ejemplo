package com.prueba.service;

import com.prueba.model.Paciente;

public interface IpacienteService extends ICRUD <Paciente> {

}
