package com.prueba.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prueba.model.Paciente;

public interface IpacienteDAO extends JpaRepository<Paciente, Integer>{

}
